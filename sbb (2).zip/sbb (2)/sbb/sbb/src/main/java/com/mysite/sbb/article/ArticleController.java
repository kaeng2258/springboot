package com.mysite.sbb.article;

import com.mysite.sbb.user.SiteUser;
import com.mysite.sbb.user.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.security.Principal;

@RequiredArgsConstructor
@Controller
public class ArticleController {

    private final ArticleService articleService;
    private final UserService userService;

    @GetMapping({"/article", "/article/list"})
    public String list(Model model,
                       @RequestParam(value = "page", defaultValue = "0") int page,
                       @RequestParam(value = "kw", defaultValue = "") String kw) {
        Page<Article> paging = this.articleService.getList(page, kw);
        model.addAttribute("paging", paging);
        model.addAttribute("kw", kw);
        return "article/list";
    }

    @GetMapping("/article/detail/{id}")
    public String detail(Model model, @PathVariable("id") Integer id) {
        Article article = this.articleService.get(id);
        model.addAttribute("article", article);
        return "article/detail";
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/article/create")
    public String createForm(ArticleForm articleForm) {
        return "article/form";
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/article/create")
    public String create(@Valid ArticleForm articleForm, BindingResult bindingResult, Principal principal) {
        if (bindingResult.hasErrors()) {
            return "article/form"; // ← 변경
        }
        SiteUser siteUser = this.userService.getUser(principal.getName());
        this.articleService.create(articleForm.getSubject(), articleForm.getContent(), siteUser);
        return "redirect:/article/list";
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/article/modify/{id}")
    public String modifyForm(ArticleForm articleForm, @PathVariable("id") Integer id,
                             Principal principal, Model model) {
        Article article = this.articleService.get(id);
        if (!article.getAuthor().getUsername().equals(principal.getName())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
        }
        articleForm.setSubject(article.getSubject());
        articleForm.setContent(article.getContent());
        model.addAttribute("article", article); // 수정 모드 표시용
        return "article/form"; // ← 변경
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/article/modify/{id}")
    public String modify(@Valid ArticleForm articleForm, BindingResult bindingResult,
                         Principal principal, @PathVariable("id") Integer id, Model model) {
        Article article = this.articleService.get(id);
        if (!article.getAuthor().getUsername().equals(principal.getName())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
        }
        if (bindingResult.hasErrors()) {
            model.addAttribute("article", article); // 에러 시에도 수정 모드 유지
            return "article/form"; // ← 변경
        }
        this.articleService.modify(article, articleForm.getSubject(), articleForm.getContent());
        return "redirect:/article/detail/" + id;
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/article/delete/{id}")
    public String delete(Principal principal, @PathVariable("id") Integer id) {
        Article article = this.articleService.get(id);
        if (!article.getAuthor().getUsername().equals(principal.getName())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "삭제권한이 없습니다.");
        }
        this.articleService.delete(article);
        return "redirect:/article/list";
    }
}
