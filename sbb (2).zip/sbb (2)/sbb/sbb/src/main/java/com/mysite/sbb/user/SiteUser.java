package com.mysite.sbb.user;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class SiteUser {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String username;

    private String password;

    @Column(unique = true)
    private String email;

    @Column
    private String profile_image_url;

    @Column
    private String profile_filename;

    @Column
    private String profile_content_type;

    @Column
    private Long profile_size;

    @Column
    private String nickname;

    @Column
    private String introduce;
}