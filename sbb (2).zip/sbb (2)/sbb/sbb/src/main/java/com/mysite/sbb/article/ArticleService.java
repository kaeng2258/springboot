package com.mysite.sbb.article;

import com.mysite.sbb.DataNotFoundException;
import com.mysite.sbb.user.SiteUser;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@RequiredArgsConstructor
@Service
public class ArticleService {

    private final ArticleRepository articleRepository;

    public List<Article> getList() {
        return articleRepository.findAll();
    }

    public Article get(Integer id) {
        return articleRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundException("article not found"));
    }

    public void create(String subject, String content, SiteUser user) {
        Article a = new Article();
        a.setSubject(subject);
        a.setContent(content);
        a.setAuthor(user);
        a.setCreateDate(LocalDateTime.now());
        articleRepository.save(a);
    }

    public Page<Article> getList(int page, String kw) {
        Pageable pageable = PageRequest.of(page, 10, Sort.by(Sort.Order.desc("createDate")));
        if (kw == null || kw.isBlank()) {
            return articleRepository.findAll(pageable);
        }

        return articleRepository.findAllByKeyword(kw, pageable);
    }

    public void modify(Article article, String subject, String content) {
        article.setSubject(subject);
        article.setContent(content);
        article.setModifyDate(LocalDateTime.now());
        articleRepository.save(article);
    }

    public void delete(Article article) {
        articleRepository.delete(article);
    }
}
